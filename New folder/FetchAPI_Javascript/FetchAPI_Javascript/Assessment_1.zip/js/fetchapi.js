function fetchData() {

    fetch("https://jsonplaceholder.typicode.com/posts")
        .then(response => {
            if (!response.ok) {
                throw Error("ERROR");
            }
            return response.json();
        })
        .then(data => {
            // console.log(data);
            const html = data.map(posts => {
                return `
                <div class="card text-white bg-info mb-3" style="max-width: 100%;">
                    <div class="card-body">
                        <h5 class="card-title">${posts.title}</h5>
                        <p class="card-text">${posts.body}</p>
                    </div>
                </div>
            `
            }).join("");
            // console.log(html);
            document.querySelector('#app')
                .insertAdjacentHTML("afterbegin", html);
        })
        .catch(error => {
            console.log(error);
        });
}
fetchData();